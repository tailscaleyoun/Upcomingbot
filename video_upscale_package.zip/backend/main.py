from flask import Flask, request, jsonify, send_from_directory
import os
import subprocess
from werkzeug.utils import secure_filename

app = Flask(__name__, static_folder=None)

UPLOAD_FOLDER = "uploads"
OUTPUT_FOLDER = "output"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

ALLOWED_EXTENSIONS = {'mp4'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/")
def home():
    return "Video Upscale API is running ✅"

@app.route("/upscale", methods=["POST"])
def upscale():
    if "file" not in request.files:
        return jsonify({"error": "No video uploaded"}), 400

    file = request.files["file"]
    filename = secure_filename(file.filename)
    if not allowed_file(filename):
        return jsonify({"error": "Only MP4 files are allowed in this package"}), 400

    input_path = os.path.join(UPLOAD_FOLDER, filename)
    output_filename = f"enhanced_{filename}"
    output_path = os.path.join(OUTPUT_FOLDER, output_filename)

    file.save(input_path)

    # Placeholder for Real-ESRGAN processing.
    # This package assumes you will install and configure realesrgan-ncnn-vulkan or other tool.
    # For now we'll simulate processing by copying the file (replace this with actual command).
    try:
        # Example actual command (uncomment when realesrgan-ncnn-vulkan is installed on server):
        # subprocess.run([
        #     "realesrgan-ncnn-vulkan",
        #     "-i", input_path,
        #     "-o", output_path,
        #     "-s", "2"
        # ], check=True)

        # Simulate processing: copy input to output
        import shutil
        shutil.copy(input_path, output_path)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    # Return URL to download the processed file. On Render this will work if static files are served or via stream endpoint.
    return jsonify({"url": f"/download/{output_filename}"})

@app.route("/download/<path:filename>")
def download_file(filename):
    return send_from_directory(OUTPUT_FOLDER, filename, as_attachment=False)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 10000)))
